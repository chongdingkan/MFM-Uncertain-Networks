"""Artificial-fixture correctness checks; no manuscript results are generated."""

import ast
import csv
import gzip
import importlib.util
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import networkx as nx
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("table_v_workflow", HERE / "run.py")
workflow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(workflow)


class WorkflowChecks(unittest.TestCase):
    def test_archive_magic_and_undirected_deduplication(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "misnamed.zip"
            path.write_bytes(gzip.compress(b"# fixture\n0 1\n1 0\n1 1\n1 2\n"))
            graph = workflow.read_edge_list(path)
            self.assertEqual(set(graph.edges()), {(0, 1), (1, 2)})

    def test_attack_precedes_probe_and_failed_probe_is_charged(self):
        graph = nx.path_graph(3)
        edges = list(graph.edges())
        ones = dict.fromkeys(edges, 1.0)
        trace = []
        result = workflow.simulate(graph, 0, 2, ones, ones, ones, ones,
                                   set(edges), edges, set(), trace=trace)
        # Destination-incident (1,2) is protected after (0,1) is destroyed.
        self.assertEqual(trace[0]["probe"], (1, 2))
        self.assertTrue(trace[0]["success"])
        self.assertFalse(trace[1]["success"])
        self.assertEqual(result["cost"], 2.0)
        self.assertEqual(result["successful_probes"], 1)
        self.assertEqual(result["flow"], 0.0)

    def test_observed_attack_skips_probe(self):
        graph = nx.Graph([(0, 1)])
        values = {(0, 1): 1.0}
        result = workflow.simulate(graph, 0, 1, values, values, values, values,
                                   {(0, 1)}, [(0, 1)], {(0, 1)})
        self.assertEqual(result["probes"], 0)
        self.assertEqual(result["cost"], 0.0)

    def test_absent_probe_cannot_create_flow(self):
        graph = nx.Graph([(0, 1)])
        values = {(0, 1): 1.0}
        result = workflow.simulate(graph, 0, 1, values, values, values, values,
                                   set(), [], set())
        self.assertEqual(result["cost"], 1.0)
        self.assertEqual(result["successful_probes"], 0)
        self.assertEqual(result["flow"], 0.0)

    def test_protected_link_survives_later_attack(self):
        graph = nx.path_graph(3)
        edges = list(graph.edges())
        values = dict.fromkeys(edges, 1.0)
        trace = []
        result = workflow.simulate(graph, 0, 2, values, values, values, values,
                                   set(edges), [(0, 1), (1, 2)], set(), trace=trace)
        self.assertEqual(result["successful_probes"], 1)
        self.assertEqual(trace[0]["probe"], (1, 2))
        # The second attack targets the already protected edge; it survives.
        self.assertFalse(trace[1]["success"])

    def test_standard_maxflow_respects_shared_edge_capacity(self):
        graph = nx.Graph([(0, 1), (1, 2), (1, 3), (2, 4), (3, 4)])
        graph = nx.Graph(sorted(tuple(sorted(e)) for e in graph.edges()))
        edges = list(graph.edges())
        # Canonical endpoints for the simulator's edge-key contract.
        graph2 = nx.Graph()
        graph2.add_nodes_from(sorted(graph.nodes()))
        graph2.add_edges_from(sorted(tuple(sorted(e)) for e in edges))
        edges = list(graph2.edges())
        values = dict.fromkeys(edges, 1.0)
        result = workflow.simulate(graph2, 0, 4, values, values, values, values,
                                   set(edges), [], set())
        self.assertEqual(result["flow"], 1.0)  # Two paths share (0,1).

    def test_ablation_changes_score_not_charge(self):
        self.assertEqual(workflow.importance(0.5, 8, 2, 3, "none"), 6)
        self.assertEqual(workflow.importance(0.5, 8, 2, 3, "topology"), 2)
        self.assertEqual(workflow.importance(0.5, 8, 2, 3, "cost"), 12)
        graph = nx.Graph([(0, 1)])
        one = {(0, 1): 1.0}
        result = workflow.simulate(graph, 0, 1, one, one, {(0, 1): 9.0}, one,
                                   {(0, 1)}, [], set(), ablation="cost")
        self.assertEqual(result["cost"], 9.0)

    def test_attack_permutations_and_named_stream_reproducibility(self):
        edges = [(0, i) for i in range(1, 9)]
        values = {e: i for i, e in enumerate(edges)}
        for kind in ("RA", "HA"):
            a = workflow.attack_order(edges, values, values, kind, workflow.rng(123, kind))
            b = workflow.attack_order(edges, values, values, kind, workflow.rng(123, kind))
            self.assertEqual(a, b)
            self.assertEqual(set(a), set(edges))
            self.assertEqual(len(a), len(set(a)))

    def test_log_normal_and_uniform_analytic_parameters(self):
        # Large sampling is unnecessary: compare against the specified generators.
        a = workflow.costs(workflow.rng(7), "Uniform", 50, 10, 5)
        b = workflow.rng(7).uniform(50 - math.sqrt(3) * 10, 50 + math.sqrt(3) * 10, 5)
        np.testing.assert_array_equal(a, b)
        variance = math.log1p(0.04)
        a = workflow.costs(workflow.rng(7), "Lognormal", 50, 10, 5)
        b = workflow.rng(7).lognormal(math.log(50) - variance / 2, math.sqrt(variance), 5)
        np.testing.assert_array_equal(a, b)

    def test_statistics_count_sample_sd_duplicates_and_missing_cells(self):
        rows = []
        for cell in workflow.configurations():
            for i, value in enumerate((1, 3)):
                rows.append(dict(**cell, pair_id=i, realization_id=0, flow=value, cost=10 * value))
        stats = workflow.summarize(rows)
        self.assertEqual(len(stats), 16)
        self.assertEqual(stats[0]["flow_mean"], 2)
        self.assertAlmostEqual(stats[0]["flow_std"], math.sqrt(2))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            workflow.summarize(rows + [rows[0]])
        with self.assertRaisesRegex(ValueError, "Missing"):
            workflow.summarize(rows[2:])

    def test_outcomes_match_public_heu_after_initialization_typo_fix(self):
        # Load only the historical function, correcting its undefined `edge`
        # initializer in memory. The repository's original file is untouched.
        source = (HERE.parents[1] / "code.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        function = next(node for node in tree.body
                        if isinstance(node, ast.FunctionDef) and node.name == "HEU")
        initialization = function.body[0].value
        self.assertIsInstance(initialization, ast.DictComp)
        self.assertEqual(initialization.key.id, "edge")
        initialization.key.id = "e"
        module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
        namespace = {"backtrack": lambda previous, *args: previous}
        exec(compile(module, "legacy_HEU_with_typo_fix", "exec"), namespace)
        graph = nx.complete_graph(5)
        edges = list(graph.edges())
        generator = workflow.rng(17, "compatibility_fixture")
        for ablation in ("none", "probability", "topology", "capacity", "cost"):
            probability = {e: float(x) for e, x in zip(edges, generator.random(len(edges)))}
            capacity = {e: float(x) for e, x in zip(edges, generator.uniform(1, 5, len(edges)))}
            cost = {e: float(x) for e, x in zip(edges, generator.uniform(1, 5, len(edges)))}
            topology = {e: float(x) for e, x in zip(edges, generator.uniform(1, 5, len(edges)))}
            present = {e for e, x in zip(edges, generator.random(len(edges))) if x < probability[e]}
            order = workflow.attack_order(edges, probability, capacity, "HA", generator)
            observed = {e for e, x in zip(edges, generator.random(len(edges))) if x < 0.5}
            edge_info = {}
            for e in edges:
                score = workflow.importance(probability[e], capacity[e], cost[e], topology[e], ablation)
                edge_info[e] = dict(probability=probability[e], capacity=capacity[e], cost=cost[e],
                                    importance_b=score, importance_d=score)
            selected, legacy_cost = namespace["HEU"](
                graph, edge_info, 0, 4, order, 1,
                {e: int(e in present) for e in edges}, observed)
            residual = nx.Graph()
            residual.add_nodes_from(graph.nodes())
            residual.add_edges_from((u, v, {"capacity": capacity[(u, v)]}) for u, v in selected)
            legacy_flow = nx.maximum_flow_value(residual, 0, 4)
            result = workflow.simulate(graph, 0, 4, probability, capacity, cost, topology,
                                       present, order, observed, ablation)
            self.assertAlmostEqual(result["flow"], legacy_flow)
            self.assertAlmostEqual(result["cost"], legacy_cost)

    def test_cli_artificial_fixture_and_reaggregation(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            dataset = folder / "fixture.txt"
            dataset.write_text("0 1\n0 2\n1 2\n1 3\n2 3\n3 4\n2 4\n")
            config = json.loads((HERE / "config.json").read_text())
            config.update(nodes=5, source_destination_pairs=2, realizations=2)
            config_path = folder / "config.json"
            config_path.write_text(json.dumps(config))
            output = folder / "output"
            command = [sys.executable, str(HERE / "run.py"), "--config", str(config_path),
                       "--dataset", str(dataset), "--output", str(output)]
            dry = subprocess.run(command, capture_output=True, text=True, check=True)
            self.assertIn("Dry run only", dry.stdout)
            self.assertFalse(output.exists())
            blocked = subprocess.run(command + ["--execute"], capture_output=True, text=True)
            self.assertNotEqual(blocked.returncode, 0)
            subprocess.run(command + ["--execute", "--accept-reconstruction"],
                           capture_output=True, text=True, check=True)
            summary = (output / "summary.csv").read_bytes()
            with (output / "runs.csv").open() as handle:
                self.assertEqual(len(list(csv.DictReader(handle))), 64)
            manifest = json.loads((output / "manifest.json").read_text())
            self.assertFalse(manifest["historical_table_v_numerically_verified"])
            subprocess.run([sys.executable, str(HERE / "run.py"), "--aggregate-only",
                            "--output", str(output)], capture_output=True, text=True, check=True)
            self.assertEqual(summary, (output / "summary.csv").read_bytes())
            # Repeated fixed-seed execution writes identical scientific records.
            second = folder / "second"
            command[command.index(str(output))] = str(second)
            subprocess.run(command + ["--execute", "--accept-reconstruction"],
                           capture_output=True, text=True, check=True)
            for name in ("runs.csv", "instances.json", "summary.csv"):
                self.assertEqual((output / name).read_bytes(), (second / name).read_bytes())
            with (output / "runs.csv").open() as handle:
                records = list(csv.DictReader(handle))
            # A missing record must never silently produce a complete table.
            workflow.write_csv(output / "runs.csv", workflow.FIELDS, records[1:])
            bad = subprocess.run([sys.executable, str(HERE / "run.py"), "--aggregate-only",
                                  "--output", str(output)], capture_output=True, text=True)
            self.assertNotEqual(bad.returncode, 0)


if __name__ == "__main__":
    unittest.main()
