# Maximum-Flow Maintenance in Uncertain Networks

This repository contains the source code and datasets for our paper on defending uncertain networks against adversarial interdiction.

## Datasets
The dataset archives are in the repository root:
- Facebook Ego Network
- EU-Email Network

## Requirements
- Python 3.8+
- NetworkX
- Pandas
- NumPy

## Table V: sensitivity and component ablation

The targeted workflow, configuration, statistical aggregation, and run commands
are documented in [experiments/table_v/README.md](experiments/table_v/README.md).
It covers HEU cost sensitivity (Gaussian/Uniform/Lognormal) and four score
ablations under RA and HA on a 100-node EU-Email graph.

This is a reconstructed implementation, not the recovered historical scripts.
The original Table V drivers and run-level records are unavailable; numerical
agreement with the printed table has not been established. Historical choices
that were not recorded, and differences between the existing HEU function and
Algorithm 2's candidate-selection description, are stated explicitly in that
document. The full experimental batch has not been run for this addition.
