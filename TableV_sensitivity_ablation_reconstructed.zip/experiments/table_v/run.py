"""Reconstructed Table V workflow; see README.md for historical limitations.

The implementation never reads the printed Table V values. No numerical
agreement with that table is asserted. Run without --execute for a dry run.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import io
import json
import math
import platform
import statistics
import sys
import zipfile
from collections import deque
from pathlib import Path

import networkx as nx
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STATUS = "reconstructed_2026-11-01_not_historical_scripts"
FIELDS = ["analysis", "attack", "configuration", "cost_distribution", "ablation",
          "pair_id", "realization_id", "source", "target", "flow", "cost",
          "probes", "rounds", "successful_probes", "observed_attacks"]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rng(seed, *labels):
    """Stable named streams: adding a configuration does not shift other draws."""
    data = json.dumps([seed, *labels], separators=(",", ":")).encode()
    value = int.from_bytes(hashlib.sha256(data).digest()[:16], "little")
    return np.random.Generator(np.random.PCG64(value))


def read_edge_list(path, member=None):
    """Detect compression by bytes, including the repository's mislabeled gzip."""
    data = Path(path).read_bytes()
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    elif data[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            names = [n for n in archive.namelist() if not n.endswith("/")
                     and not n.startswith("__MACOSX/")]
            if member is None and len(names) != 1:
                raise ValueError("ZIP has multiple files; specify --archive-member")
            data = archive.read(member if member is not None else names[0])
    graph = nx.Graph()
    for number, line in enumerate(data.decode("utf-8-sig").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith(("#", "%")):
            continue
        fields = line.split()
        if len(fields) < 2:
            raise ValueError(f"Invalid edge-list line {number}")
        u, v = int(fields[0]), int(fields[1])
        graph.add_nodes_from((u, v))
        if u != v:
            graph.add_edge(u, v)
    if graph.number_of_edges() == 0:
        raise ValueError("Dataset has no non-loop edges")
    return graph


def select_nodes(graph, count, node_file=None):
    if node_file is not None:
        nodes = [int(x) for x in Path(node_file).read_text().split()]
        if len(nodes) != count or len(set(nodes)) != count:
            raise ValueError("Node file must contain exactly the requested unique nodes")
        if any(n not in graph for n in nodes):
            raise ValueError("Node file references an unknown node")
    else:
        components = sorted(nx.connected_components(graph),
                            key=lambda c: (-len(c), min(c)))
        component = components[0]
        if len(component) < count:
            raise ValueError("Largest component is smaller than requested node count")
        start = min(component, key=lambda n: (-graph.degree(n), n))
        queue, seen, nodes = deque([start]), {start}, []
        while queue and len(nodes) < count:
            u = queue.popleft()
            nodes.append(u)
            for v in sorted(graph.neighbors(u)):
                if v not in seen:
                    seen.add(v)
                    queue.append(v)
    subgraph = graph.subgraph(nodes)
    if not nx.is_connected(subgraph):
        raise ValueError("Selected potential graph must be connected")
    result = nx.Graph()
    result.add_nodes_from(sorted(nodes))
    result.add_edges_from(sorted((min(u, v), max(u, v)) for u, v in subgraph.edges()))
    return result


def positive_normal(generator, mean, std, size):
    """Reject nonpositive samples rather than clipping them to zero."""
    values = generator.normal(mean, std, size)
    bad = values <= 0
    while np.any(bad):
        values[bad] = generator.normal(mean, std, int(bad.sum()))
        bad = values <= 0
    return values


def costs(generator, distribution, mean, std, size):
    if distribution == "Gaussian":
        return positive_normal(generator, mean, std, size)
    if distribution == "Uniform":
        half_width = math.sqrt(3) * std
        if mean <= half_width:
            raise ValueError("Moment-matched uniform distribution must be positive")
        return generator.uniform(mean - half_width, mean + half_width, size)
    if distribution == "Lognormal":
        variance = math.log1p((std / mean) ** 2)
        return generator.lognormal(math.log(mean) - variance / 2, math.sqrt(variance), size)
    raise ValueError(f"Unknown cost distribution: {distribution}")


def configurations():
    cells = []
    for attack in ("RA", "HA"):
        for distribution in ("Gaussian", "Uniform", "Lognormal"):
            cells.append(dict(analysis="cost_sensitivity", attack=attack,
                              configuration=distribution,
                              cost_distribution=distribution, ablation="none"))
    for attack in ("RA", "HA"):
        for label, ablation in (("Full score", "none"), ("Without p(e)", "probability"),
                                ("Without topology", "topology"),
                                ("Without k(e)", "capacity"), ("Without c(e)", "cost")):
            cells.append(dict(analysis="score_ablation", attack=attack,
                              configuration=label, cost_distribution="Gaussian",
                              ablation=ablation))
    return cells


def importance(probability, capacity, cost, topology, ablation):
    """An ablated multiplicative factor is replaced by one, not zero."""
    return ((1.0 if ablation == "probability" else probability)
            * (1.0 if ablation == "topology" else topology)
            * (1.0 if ablation == "capacity" else capacity)
            / (1.0 if ablation == "cost" else cost))


def attack_order(edges, probability, capacity, kind, generator):
    """No repeated targets, no dependence on defender protection or realization."""
    if kind == "RA":
        return [edges[int(i)] for i in generator.permutation(len(edges))]
    if kind != "HA":
        raise ValueError(f"Unsupported Table V attack: {kind}")
    # Equal total quotas (difference at most one); interleave them across rounds.
    m = len(edges)
    tokens = [name for i, name in enumerate(("RA", "PD", "KD"))
              for _ in range(m // 3 + (i < m % 3))]
    generator.shuffle(tokens)
    tie = {e: float(x) for e, x in zip(edges, generator.random(m))}
    queues = {
        "RA": [edges[int(i)] for i in generator.permutation(m)],
        "PD": sorted(edges, key=lambda e: (-probability[e], tie[e], e)),
        "KD": sorted(edges, key=lambda e: (-capacity[e], tie[e], e)),
    }
    positions, used, output = {name: 0 for name in queues}, set(), []
    for name in tokens:
        queue = queues[name]
        while positions[name] < m and queue[positions[name]] in used:
            positions[name] += 1
        edge = queue[positions[name]]
        positions[name] += 1
        used.add(edge)
        output.append(edge)
    return output


def simulate(graph, source, target, probability, capacity, cost, topology,
             present, attack_log, observed, ablation="none", attacks_per_round=1,
             trace=None):
    """Use the public HEU candidate rule with explicit physical/observed states.

    Source code HEU selects a target-incident unresolved link if one exists,
    otherwise the global maximum-score link. It does not implement Algorithm 2's
    stated source-path backtracking. This distinction is documented, not hidden.
    """
    edges = list(graph.edges())
    unresolved, attacked, protected = set(edges), set(), set()
    scores = {e: importance(probability[e], capacity[e], cost[e], topology[e], ablation)
              for e in edges}
    spent, probes, rounds, observed_count, index = 0.0, 0, 0, 0, 0
    while unresolved:
        rounds += 1
        attempted = attack_log[index:index + attacks_per_round]
        index += len(attempted)
        for edge in attempted:
            if edge not in protected:
                attacked.add(edge)
            if edge in observed:
                observed_count += 1
                unresolved.discard(edge)
        if not unresolved:
            if trace is not None:
                trace.append(dict(attacks=attempted, probe=None))
            break
        candidates = sorted(e for e in unresolved if target in e)
        if not candidates:
            candidates = sorted(unresolved)
        best = max(candidates, key=lambda e: scores[e])
        unresolved.remove(best)
        spent += cost[best]  # Charge absent/previously destroyed probes as well.
        probes += 1
        success = best in present and best not in attacked
        if success:
            protected.add(best)
        if trace is not None:
            trace.append(dict(attacks=attempted, probe=best, success=success,
                              score=scores[best]))
        if rounds > len(edges):
            raise RuntimeError("Progress invariant violated")
    residual = nx.Graph()
    residual.add_nodes_from(graph.nodes())
    for u, v in sorted(protected):
        residual.add_edge(u, v, capacity=capacity[(u, v)])
    flow = nx.maximum_flow_value(residual, source, target, capacity="capacity")
    return dict(flow=float(flow), cost=float(spent), probes=probes, rounds=rounds,
                successful_probes=len(protected), observed_attacks=observed_count)


def summarize(rows):
    groups = {}
    seen = set()
    for row in rows:
        key = tuple(row[k] for k in ("analysis", "attack", "configuration"))
        identity = (*key, str(row["pair_id"]), str(row["realization_id"]))
        if identity in seen:
            raise ValueError(f"Duplicate run: {identity}")
        seen.add(identity)
        if not all(math.isfinite(float(row[k])) and float(row[k]) >= 0
                   for k in ("flow", "cost")):
            raise ValueError("Flow and cost must be finite and nonnegative")
        groups.setdefault(key, []).append(row)
    output = []
    for cell in configurations():
        key = tuple(cell[k] for k in ("analysis", "attack", "configuration"))
        records = groups.pop(key, [])
        if not records:
            raise ValueError(f"Missing table cell: {key}")
        if any(r["cost_distribution"] != cell["cost_distribution"]
               or r["ablation"] != cell["ablation"] for r in records):
            raise ValueError(f"Configuration metadata disagree for {key}")
        flow = [float(r["flow"]) for r in records]
        cost = [float(r["cost"]) for r in records]
        if len(records) < 2:
            raise ValueError("Sample standard deviation requires at least two runs")
        output.append(dict(**cell, n=len(records), flow_mean=statistics.mean(flow),
                           flow_std=statistics.stdev(flow), cost_mean=statistics.mean(cost),
                           cost_std=statistics.stdev(cost)))
    if groups:
        raise ValueError(f"Unexpected cells: {list(groups)}")
    return output


def write_csv(path, fields, rows):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def aggregate(path, output, manifest):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    config = manifest["configuration"]
    expected_ids = {(str(i), str(j)) for i in range(config["source_destination_pairs"])
                    for j in range(config["realizations"])}
    stats = summarize(rows)
    for cell in configurations():
        selected = [r for r in rows if all(r[k] == cell[k]
                    for k in ("analysis", "attack", "configuration"))]
        actual_ids = {(r["pair_id"], r["realization_id"]) for r in selected}
        if actual_ids != expected_ids:
            raise ValueError("Incomplete or unexpected pair/realization IDs")
    write_csv(output / "summary.csv", list(stats[0]), stats)
    lines = ["# Reconstructed workflow output", "",
             "These are newly generated outputs, not recovered historical results.",
             "They have not been certified to reproduce the printed Table V.", "",
             "| Analysis | Attack | Configuration | n | Flow mean ± sample SD | Cost mean ± sample SD |",
             "|---|---|---|---:|---:|---:|"]
    for row in stats:
        lines.append(f"| {row['analysis']} | {row['attack']} | {row['configuration']} | "
                     f"{row['n']} | {row['flow_mean']:.2f} ± {row['flow_std']:.2f} | "
                     f"{row['cost_mean']:.1f} ± {row['cost_std']:.1f} |")
    (output / "table_v.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest["outputs"] = {name: sha256(output / name)
                           for name in ("runs.csv", "summary.csv", "table_v.md")}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def validate_config(config):
    if config.get("schema_version") != 1:
        raise ValueError("Unsupported configuration schema")
    if config.get("implementation_status") != STATUS:
        raise ValueError("Implementation status must identify the reconstructed workflow")
    for key in ("nodes", "source_destination_pairs", "realizations", "attacks_per_round"):
        if type(config[key]) is not int or config[key] <= 0:
            raise ValueError(f"{key} must be a positive integer")
    if config["nodes"] < 2 or config["source_destination_pairs"] * config["realizations"] < 2:
        raise ValueError("Need at least two nodes and two observations per cell")
    if not 0 <= config["visibility"] <= 1:
        raise ValueError("Visibility must be in [0,1]")
    for key in ("cost_mean", "cost_std", "capacity_mean", "capacity_std"):
        if not math.isfinite(config[key]) or config[key] <= 0:
            raise ValueError(f"{key} must be finite and positive")
    if config["cost_mean"] <= math.sqrt(3) * config["cost_std"]:
        raise ValueError("Uniform cost lower bound must be positive")
    if config["degree"] not in ("raw", "normalized"):
        raise ValueError("degree must be raw or normalized")
    if type(config["seed"]) is not int or config["seed"] < 0:
        raise ValueError("seed must be a nonnegative integer")
    if type(config["betweenness_normalized"]) is not bool:
        raise ValueError("betweenness_normalized must be boolean")
    if config["selection_rule"] != "public_HEU_target_incident_then_global":
        raise ValueError("Unsupported selection rule")
    if config["node_selection"] != "bfs_from_highest_degree_node_sorted_neighbors":
        raise ValueError("Unsupported automatic node selection")
    if config["hybrid_schedule"] != "shuffle_equal_RA_PD_KD_tokens_then_select_unattacked_edge":
        raise ValueError("Unsupported HA schedule")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=HERE / "config.json")
    parser.add_argument("--dataset", type=Path)
    parser.add_argument("--archive-member")
    parser.add_argument("--node-file", type=Path)
    parser.add_argument("--output", type=Path, default=HERE / "results")
    parser.add_argument("--execute", action="store_true", help="Run the requested experiments")
    parser.add_argument("--accept-reconstruction", action="store_true",
                        help="Acknowledge that historical settings/outputs are unavailable")
    parser.add_argument("--aggregate-only", action="store_true")
    args = parser.parse_args(argv)
    if args.aggregate_only:
        if args.execute:
            parser.error("--aggregate-only and --execute are mutually exclusive")
        manifest = json.loads((args.output / "manifest.json").read_text())
        validate_config(manifest["configuration"])
        if manifest["implementation_status"] != STATUS:
            parser.error("Unexpected implementation status in manifest")
        if (args.output / "instances.json").exists():
            if sha256(args.output / "instances.json") != manifest["instances_sha256"]:
                parser.error("Instance record hash does not match manifest")
        aggregate(args.output / "runs.csv", args.output, manifest)
        print(f"Re-aggregated {args.output / 'runs.csv'}")
        return
    config = json.loads(args.config.read_text(encoding="utf-8"))
    validate_config(config)
    dataset = args.dataset or ROOT / config["dataset"]
    original = read_edge_list(dataset, args.archive_member)
    graph = select_nodes(original, config["nodes"], args.node_file)
    plan = dict(implementation_status=STATUS, nodes=len(graph), edges=graph.number_of_edges(),
                cells=len(configurations()), runs_per_cell=config["source_destination_pairs"]
                * config["realizations"], configuration=config)
    print(json.dumps(plan, indent=2))
    if not args.execute:
        print("Dry run only: no simulations or results were generated.")
        return
    if not args.accept_reconstruction:
        parser.error("Execution requires --accept-reconstruction; see README.md")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("Output directory is nonempty; choose a new directory")
    args.output.mkdir(parents=True, exist_ok=True)
    edges, nodes = list(graph.edges()), list(graph.nodes())
    neighbors = {v: set(graph.neighbors(v)) for v in nodes}
    probability = {e: len(neighbors[e[0]] & neighbors[e[1]])
                   / len(neighbors[e[0]] | neighbors[e[1]]) for e in edges}
    degree = dict(graph.degree()) if config["degree"] == "raw" else nx.degree_centrality(graph)
    betweenness = nx.betweenness_centrality(graph, normalized=config["betweenness_normalized"])
    topology = {e: degree[e[0]] + degree[e[1]] + betweenness[e[0]] + betweenness[e[1]]
                for e in edges}
    pair_rng = rng(config["seed"], "pairs")
    pairs = [tuple(int(n) for n in pair_rng.choice(nodes, 2, replace=False))
             for _ in range(config["source_destination_pairs"])]
    manifest = dict(implementation_status=STATUS, configuration=config,
                    historical_table_v_numerically_verified=False,
                    dataset_sha256=sha256(dataset), config_sha256=sha256(args.config),
                    source_sha256=sha256(__file__),
                    python=platform.python_version(), networkx=nx.__version__, numpy=np.__version__,
                    graph=dict(nodes=nodes, edges=len(edges),
                               node_selection="explicit_node_file" if args.node_file else config["node_selection"]),
                    pairs=pairs, random_generator="PCG64 with SHA-256 named streams",
                    base_repository_commit="58f3470",
                    design="10 pairs x 10 shared realizations by default; paired configurations within each analysis")
    instances, rows = [], []
    for analysis in ("cost_sensitivity", "score_ablation"):
        for realization_id in range(config["realizations"]):
            capacity_values = positive_normal(rng(config["seed"], analysis, realization_id, "capacity"),
                                             config["capacity_mean"], config["capacity_std"], len(edges))
            capacity = dict(zip(edges, map(float, capacity_values)))
            present = {e for e, draw in zip(edges, rng(config["seed"], analysis, realization_id,
                                                      "existence").random(len(edges)))
                       if draw < probability[e]}
            distributions = ("Gaussian", "Uniform", "Lognormal") if analysis == "cost_sensitivity" else ("Gaussian",)
            cost_maps = {name: dict(zip(edges, map(float, costs(
                rng(config["seed"], analysis, realization_id, "cost", name), name,
                config["cost_mean"], config["cost_std"], len(edges))))) for name in distributions}
            instance = dict(analysis=analysis, realization_id=realization_id,
                            edges=[dict(u=e[0], v=e[1], probability=probability[e], capacity=capacity[e],
                                        present=e in present, topology=topology[e],
                                        costs={name: values[e] for name, values in cost_maps.items()})
                                   for e in edges], attacks=[])
            for pair_id, (source, target) in enumerate(pairs):
                for attack in ("RA", "HA"):
                    labels = (analysis, realization_id, pair_id, attack)
                    order = attack_order(edges, probability, capacity, attack,
                                         rng(config["seed"], *labels, "order"))
                    observed = {e for e, draw in zip(edges, rng(config["seed"], *labels,
                                                               "visibility").random(len(edges)))
                                if draw < config["visibility"]}
                    instance["attacks"].append(dict(pair_id=pair_id, attack=attack, order=order,
                                                     observed=sorted(observed)))
                    for cell in configurations():
                        if cell["analysis"] != analysis or cell["attack"] != attack:
                            continue
                        result = simulate(graph, source, target, probability, capacity,
                                          cost_maps[cell["cost_distribution"]], topology, present,
                                          order, observed, cell["ablation"], config["attacks_per_round"])
                        rows.append(dict(**cell, pair_id=pair_id, realization_id=realization_id,
                                         source=source, target=target, **result))
            instances.append(instance)
            print(f"Completed {analysis} realization {realization_id + 1}/{config['realizations']}")
    (args.output / "instances.json").write_text(json.dumps(instances, separators=(",", ":")) + "\n")
    manifest["instances_sha256"] = sha256(args.output / "instances.json")
    write_csv(args.output / "runs.csv", FIELDS, rows)
    aggregate(args.output / "runs.csv", args.output, manifest)
    print(f"Saved {len(rows)} reconstructed runs; no historical numerical match is asserted.")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
